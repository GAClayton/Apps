/*
#############################################################################################################
# Author:     George Clayton
# Assignment: WE4.0 Stream A, Mobile Web Applications, Angular Todo App, Digital Skills Academy
# Student ID: D15126849 
# Date :      2016/07/06
# Email:      George.Clayton@webelevate.ie  or  GAClayton@Hotmail.com
# Extracurricular online tutorials and reading pages:
# Ref: http://www.angularjsbook.com/  An interactive book on AngularJS
# Ref: http://coursesweb.net/         JavaScript
# Ref: http://CodeAcademy.com         AngularJS
# Ref: http://KhanAcademy.com         HTML5
# Ref: https://www.ng-book.com/       Online Snippets from Angular Books 1 and 2
# Ref: Youtube Channel "Lecture Snippets" AngularJS
# Ref: Youtube Channel "Codecourse"       Phonegap
# Ref: Youtube Channel ng-class for Angular JS
# Code reuse:
# Ref: http://meyerweb.com/eric/tools/css/reset/reset.css for the CSS file
# Ref: https://youtu.be/pCOneRpqVAs Youtube - How to create a ToDo list with Phonegap for the code structure
# Bibliography:
# Ref: Learning AngularJS by Ken Williamson (Author), O'Reilly Media Inc, March 2015 Pages 37 - 54 Controllers
# Ref: AngularJS 1st Edition by Brad Green (Author), Shyam Seshadri (Author) O'Reilly Media Inc, 2013.
##############################################################################################################
 AngularJS v1.5.8
 (c) 2010-May 2016 Google, Inc. http://angularjs.org
*/
var todo_list = angular.module('TodoListApp', [])
  .controller('ListController', function($scope) 
  {

    $scope.items = [
      { detail: 'ECI Unit 12 eLearning', stat: 'Complete'},
      { detail: 'MWA Unit 11 Workshop', stat: 'Active'},
      { detail: 'SSWD Unit 7 Workshop', stat: 'Active'}
    ];

    $scope.addItem = function () {
      $scope.items.push(
        {
          detail: $scope.newItem.detail,
          stat: 'Active'
        });
    }

    $scope.deleteItem = function (item) {
      var index = $scope.items.indexOf(item);
      $scope.items.splice(index, 1);     
    }

    $scope.completeItem = function (item){
      item.stat = 'Complete';
    }

  });

function changeTab(index)
{
  switch(index)
  {
  case 1:
    document.getElementById("all_list_wrapper").style.display = "block";
    document.getElementById("active_list_wrapper").style.display = "none";
    document.getElementById("complete_list_wrapper").style.display = "none";
    break;
  case 2:
    document.getElementById("all_list_wrapper").style.display = "none";
    document.getElementById("active_list_wrapper").style.display = "block";
    document.getElementById("complete_list_wrapper").style.display = "none";
    break;
  case 3:
    document.getElementById("all_list_wrapper").style.display = "none";
    document.getElementById("active_list_wrapper").style.display = "none";
    document.getElementById("complete_list_wrapper").style.display = "block";
    break;
  default:;
  }
}